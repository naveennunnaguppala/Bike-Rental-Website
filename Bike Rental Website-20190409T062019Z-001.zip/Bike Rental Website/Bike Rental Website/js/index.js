$('.toggle').on('click', function() {
  $('.container').stop().addClass('active');
});

$('.close').on('click', function() {
  $('.container').stop().removeClass('active');
});

var Login=[
  {
    a:"Dhanish",
    b:"Farheen"
  },
  {
    a:"Naveen",
    b:"naveen123"
  },
  {
    a:"Deshik",
    b:"Sushmitha"
  }
];
function loginer()
{
  var username=document.getElementById("user").value;
  var pass=document.getElementById("password").value;
  var i;
  var c=0;
  for(i=0;i<Login.length;i++)
  {
    if(username == Login[i].a && pass == Login[i].b)
    {
      window.open("carting.html");
      c++;
    }
  }
  if(c==0)
  {
    alert('Please Enter Valid Username/Password.');
  }
}
